create definer = root@localhost view v_type as
select `djangotest`.`djbookinfo`.`id` AS `id`, `djangotest`.`djbookinfo`.`btitle` AS `name`
from (`djangotest`.`djheroinfo`
       join `djangotest`.`djbookinfo` on ((`djangotest`.`djbookinfo`.`id` = `djangotest`.`djheroinfo`.`book_id`)));

